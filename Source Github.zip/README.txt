﻿Cách SETUP:
0. Hãy xem video trước khi làm
1. Vào file Release chỉnh lại ở mục có "<< THAY ĐỔI"
2. Vào file Packages xem cách làm.
3. Nhấn chuột phải vào file Packages, chọn 7-zip,
chọn Add to archive, đổi Archive format thành bzip2.

Mệt òi không viết nữa :v
Hãy xem video nhá :v